using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;
using System.IO;

namespace CustomModelAPI.Filters
{
    public class CustomExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            string path = "exception_log.txt";
            File.AppendAllText(path, $"{DateTime.Now} - {context.Exception.Message}\n");

            context.Result = new ObjectResult("An error occurred. Please try again.")
            {
                StatusCode = 500
            };
        }
    }
}
