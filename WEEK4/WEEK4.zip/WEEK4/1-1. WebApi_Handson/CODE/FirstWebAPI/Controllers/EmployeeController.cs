using Microsoft.AspNetCore.Mvc;
using FirstWebAPI.Models;
using System.Collections.Generic;
using System.Linq;

namespace FirstWebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeController : ControllerBase
    {
        // Hardcoded employee list (static to persist across calls)
        private static List<Employee> employees = new List<Employee>
        {
            new Employee { Id = 1, Name = "John", Role = "Developer" },
            new Employee { Id = 2, Name = "Alice", Role = "Tester" },
            new Employee { Id = 3, Name = "Bob", Role = "Manager" }
        };

        [HttpGet]
        public IEnumerable<Employee> Get()
        {
            return employees;
        }

        [HttpPut]
        public ActionResult<Employee> UpdateEmployee([FromBody] Employee updatedEmp)
        {
            if (updatedEmp.Id <= 0)
            {
                return BadRequest("Invalid employee id");
            }

            var existingEmp = employees.FirstOrDefault(e => e.Id == updatedEmp.Id);
            if (existingEmp == null)
            {
                return BadRequest("Invalid employee id");
            }

            existingEmp.Name = updatedEmp.Name;
            existingEmp.Role = updatedEmp.Role;

            return Ok(existingEmp);
        }
    }
}
