using EmployeeAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeeController : ControllerBase
    {
        // Hardcoded list of employees
        private static List<Employee> employees = new List<Employee>
        {
            new Employee { Id = 1, Name = "Raj", Department = "HR", Salary = 50000 },
            new Employee { Id = 2, Name = "Priya", Department = "IT", Salary = 60000 },
            new Employee { Id = 3, Name = "Kumar", Department = "Finance", Salary = 70000 }
        };

        [HttpPut("update")]
        public ActionResult<Employee> UpdateEmployee([FromBody] Employee updatedEmp)
        {
            if (updatedEmp.Id <= 0)
                return BadRequest("Invalid employee id");

            var emp = employees.FirstOrDefault(e => e.Id == updatedEmp.Id);
            if (emp == null)
                return BadRequest("Invalid employee id");

            // Update fields
            emp.Name = updatedEmp.Name;
            emp.Department = updatedEmp.Department;
            emp.Salary = updatedEmp.Salary;

            return Ok(emp); // return the updated employee object
        }
    }
}
