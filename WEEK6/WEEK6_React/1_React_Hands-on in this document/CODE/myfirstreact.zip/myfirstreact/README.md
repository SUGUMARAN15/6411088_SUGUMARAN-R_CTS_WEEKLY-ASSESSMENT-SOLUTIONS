# CTS React Assignment - MyFirstReact

## To Run the App

1. Open terminal
2. Run: `npm install`
3. Then: `npm start`
4. App will run at: `http://localhost:3000`

This app prints:  
**"welcome to the first session of React"** as a heading.
