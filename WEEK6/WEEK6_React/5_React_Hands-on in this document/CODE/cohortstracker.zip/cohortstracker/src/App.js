import React from 'react';
import CohortDetails from './CohortDetails';

function App() {
  const cohorts = [
    {
      name: "INTADM-MERN .NET FSD",
      trainer: "Anjali Rao",
      status: "ongoing",
      startDate: "01-Jul-2023",
      endDate: "30-Sep-2023"
    },
    {
      name: "GENINTJAVA JAVA FSD",
      trainer: "Deepak Kumar",
      status: "completed",
      startDate: "01-May-2023",
      endDate: "30-Jul-2023"
    }
  ];

  return (
    <div>
      <h1>Cohorts Details</h1>
      {cohorts.map((cohort, index) => (
        <CohortDetails key={index} cohort={cohort} />
      ))}
    </div>
  );
}

export default App;
