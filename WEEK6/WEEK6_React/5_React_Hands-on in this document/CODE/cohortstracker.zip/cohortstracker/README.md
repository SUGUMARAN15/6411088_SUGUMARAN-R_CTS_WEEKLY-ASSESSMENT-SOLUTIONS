# Cohorts Tracker App

React app that displays cohort details using **CSS Modules** and **inline styles**.

##  How to Run

```bash
npm install
npm start
