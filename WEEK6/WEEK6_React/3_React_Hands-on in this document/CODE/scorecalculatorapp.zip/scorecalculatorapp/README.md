# Score Calculator App

React app to calculate and display a student's average score using props and functional components.

##  Run the App

```bash
npm install
npm start
