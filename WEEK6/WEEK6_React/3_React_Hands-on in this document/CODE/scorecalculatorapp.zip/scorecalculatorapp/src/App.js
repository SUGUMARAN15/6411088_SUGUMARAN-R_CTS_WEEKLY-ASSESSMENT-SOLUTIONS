import { CalculateScore } from './Components/CalculateScore';

function App() {
  return (
    <div>
      <CalculateScore 
        Name="Sugumaran" 
        School="TDVM Public School" 
        Total={394} 
        goal={6} 
      />
    </div>
  );
}

export default App;
