import '../Stylesheets/mystyle.css';

const percentToDecimal = (decimal) => {
  return (decimal.toFixed(2) * 1);
};

const calcScore = (total, goal) => {
  return percentToDecimal(total / goal);
};

export const CalculateScore = ({ Name, School, Total, goal }) => {
  return (
    <div className="formatstyle">
      <h1 className="formatstyle">Student Details:</h1>
      <div className="Name">
        <span>Name: </span>
        <span>{Name}</span>
      </div>

      <div className="School">
        <span>School: </span>
        <span>{School}</span>
      </div>

      <div className="Total">
        <span>Total Marks: </span>
        <span>{Total}</span>
      </div>

      <div className="Score">
        <span>Score: </span>
        <span>{calcScore(Total, goal)}</span>
      </div>
    </div>
  );
};

export default CalculateScore;
