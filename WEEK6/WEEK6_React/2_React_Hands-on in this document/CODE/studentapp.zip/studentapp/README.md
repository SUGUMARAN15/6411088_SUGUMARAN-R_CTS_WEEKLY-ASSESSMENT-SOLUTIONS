# Student Management Portal - React App

## How to Run

1. Open terminal in this folder
2. Run: `npm install`
3. Then run: `npm start`
4. App will open at: http://localhost:3000

## Description

This React app displays:

- Home page message
- About page message
- Contact page message

All components are rendered in App.js
