# Blog App

React app that fetches and displays posts using class-based components and lifecycle methods.

##  Run the App

```bash
npm install
npm start
