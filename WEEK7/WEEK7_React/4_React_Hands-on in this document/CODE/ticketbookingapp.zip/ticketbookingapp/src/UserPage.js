import React from 'react';
import { useNavigate } from 'react-router-dom';

function UserPage({ onLogout }) {
  const navigate = useNavigate();

  const handleLogout = () => {
    onLogout();
    navigate('/guest');
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome back</h1>
      <p>Flight: AI 202 | From: Chennai | To: Mumbai | Time: 5:30 PM</p>
      <button onClick={() => alert('Ticket Booked!')}>Book Ticket</button><br /><br />
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
}

export default UserPage;
