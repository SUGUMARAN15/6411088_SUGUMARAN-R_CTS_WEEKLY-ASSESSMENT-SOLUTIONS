import React from 'react';

function FlightDetails({ isLoggedIn }) {
  return (
    <div style={{ marginTop: '20px' }}>
      <h2>Flight Details</h2>
      <p>Flight: AI 202 | From: Chennai | To: Mumbai | Time: 5:30 PM</p>
      
      {isLoggedIn ? (
        <button>Book Ticket</button>
      ) : (
        <p><i>Login to book your ticket</i></p>
      )}
    </div>
  );
}

export default FlightDetails;
