import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import GuestPage from './GuestPage';
import UserPage from './UserPage';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/guest" />} />
        <Route path="/guest" element={
          <GuestPage onLogin={() => setIsLoggedIn(true)} />
        } />
        <Route path="/user" element={
          isLoggedIn ? (
            <UserPage onLogout={() => setIsLoggedIn(false)} />
          ) : (
            <Navigate to="/guest" />
          )
        } />
      </Routes>
    </Router>
  );
}

export default App;
