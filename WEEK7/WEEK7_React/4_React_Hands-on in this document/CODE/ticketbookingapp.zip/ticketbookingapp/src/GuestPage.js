import React from 'react';
import { useNavigate } from 'react-router-dom';

function GuestPage({ onLogin }) {
  const navigate = useNavigate();

  const handleLogin = () => {
    onLogin();
    navigate('/user');
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Please sign up.</h1>
      <p>Flight: AI 202 | From: Chennai | To: Mumbai | Time: 5:30 PM</p>
      <p><i>Login to book your ticket</i></p>
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}

export default GuestPage;
