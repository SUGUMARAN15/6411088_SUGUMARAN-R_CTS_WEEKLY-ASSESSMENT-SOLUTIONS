import React, { useState } from 'react';

function CurrencyConvertor() {
  const [rupees, setRupees] = useState('');
  const [currency, setCurrency] = useState('');
  const [result, setResult] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    const currencyLower = currency.toLowerCase();

    if (currencyLower === 'euro') {
      const rate = 0.011;
      const converted = parseFloat(rupees) * rate;
      const euroValue = `€${converted.toFixed(2)}`;
      alert(`Converting to Euro Amount is ${euroValue}`);
      setResult(euroValue);
    } else {
      setResult('Unsupported currency. Try: euro');
    }
  };

  return (
    <div>
      <h2>Currency Convertor</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="number"
          placeholder="Enter amount in INR"
          value={rupees}
          onChange={(e) => setRupees(e.target.value)}
        />
        <br /><br />
        <input
          type="text"
          placeholder="Enter target currency (e.g. euro)"
          value={currency}
          onChange={(e) => setCurrency(e.target.value)}
        />
        <br /><br />
        <button type="submit">Convert</button>
      </form>

      {result && <p style={{ fontWeight: 'bold' }}>Converted: {result}</p>}
    </div>
  );
}

export default CurrencyConvertor;
