import React from 'react';
import './App.css';

function App() {
  const element = "Office Space";

  const jsxAtt = (
    <img
      src="https://images.unsplash.com/photo-1570129477492-45c003edd2be"
      width="25%"
      height="25%"
      alt="Office Space"
    />
  );

  // Single office
  const ItemName = {
    Name: "DBS",
    Rent: 50000,
    Address: "Chennai"
  };

  // Multiple office list
  const officeList = [
    { Name: "Regus", Rent: 45000, Address: "Mumbai" },
    { Name: "WeWork", Rent: 70000, Address: "Delhi" },
    { Name: "Awfis", Rent: 58000, Address: "Bangalore" }
  ];

  // Conditional color for single office
  let colors = [];
  if (ItemName.Rent <= 60000) {
    colors.push('textRed');
  } else {
    colors.push('textGreen');
  }

  return (
    <div style={{ padding: '30px' }}>
      <h1>{element} , at Affordable Range</h1>
      {jsxAtt}

      {/* Display single item */}
      <h2>Name: {ItemName.Name}</h2>
      <h3 className={colors.join(' ')}>Rent: Rs. {ItemName.Rent}</h3>
      <h3>Address: {ItemName.Address}</h3>

      <hr />

      {/* Display multiple items */}
      <h2>Available Office Spaces:</h2>
      {officeList.map((item, index) => {
        const rentClass = item.Rent <= 60000 ? 'textRed' : 'textGreen';
        return (
          <div key={index} style={{ marginBottom: '20px' }}>
            <h2>Name: {item.Name}</h2>
            <h3 className={rentClass}>Rent: Rs. {item.Rent}</h3>
            <h3>Address: {item.Address}</h3>
          </div>
        );
      })}
    </div>
  );
}

export default App;
