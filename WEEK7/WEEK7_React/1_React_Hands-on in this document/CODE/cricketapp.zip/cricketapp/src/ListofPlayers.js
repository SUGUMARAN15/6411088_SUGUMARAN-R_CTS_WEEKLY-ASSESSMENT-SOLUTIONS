import React from 'react';

function ListofPlayers() {
  const players = [
    { name: 'Virat', score: 80 },
    { name: 'Rohit', score: 45 },
    { name: 'Gill', score: 75 },
    { name: 'Rahul', score: 60 },
    { name: 'Hardik', score: 85 },
    { name: 'Pant', score: 66 },
    { name: 'Jadeja', score: 90 },
    { name: 'Shami', score: 35 },
    { name: 'Bumrah', score: 50 },
    { name: 'Surya', score: 88 },
    { name: 'Kuldeep', score: 42 },
  ];

  const players70 = [];
  players.map((item) => {
    if (item.score < 70) {
      players70.push(item);
    }
  });

  return (
    <div>
      <h3>List of Players :-</h3>
      {players.map((item) => (
        <div>
          <li>
            <span>{item.name}</span> - <span>{item.score}</span>
          </li>
        </div>
      ))}

      <h3>List of Players having Scores Less than 70</h3>
      {players70.map((item) => (
        <div>
          <li>
            <span>{item.name}</span> - <span>{item.score}</span>
          </li>
        </div>
      ))}
    </div>
  );
}

export default ListofPlayers;
