import React from 'react';
import ListofPlayers from './ListofPlayers';
import IndianPlayers from './IndianPlayers';

function App() {
  const flag = false;

  return (
    <div>
      {flag ? (
        <div>
          <h3>List of Players :-</h3>
          <ListofPlayers />
        </div>
      ) : (
        <div>
          <h3>Indian Team :-</h3>
          <IndianPlayers />
        </div>
      )}
    </div>
  );
}

export default App;
