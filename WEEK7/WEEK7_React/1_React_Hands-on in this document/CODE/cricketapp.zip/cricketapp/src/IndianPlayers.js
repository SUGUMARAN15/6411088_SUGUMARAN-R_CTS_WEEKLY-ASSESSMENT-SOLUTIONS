import React from 'react';

function IndianPlayers() {
  // Task 1: Destructuring for Odd and Even
  const players = ['Virat', 'Rohit', 'Gill', 'Rahul', 'Hardik', 'Pant'];
  const [first, second, third, fourth, fifth, sixth] = players;

  const oddTeam = [first, third, fifth];
  const evenTeam = [second, fourth, sixth];

  // Task 2: Merge arrays using spread operator
  const T20Players = ['First Player', 'Second Player', 'Third Player'];
  const RanjiTrophyPlayers = ['Fourth Player', 'Fifth Player', 'Sixth Player'];
  const mergedPlayers = [...T20Players, ...RanjiTrophyPlayers];

  return (
    <div>
      <h3>Odd Players</h3>
      <ul>
        {oddTeam.map((player, index) => (
          <li key={index}>{player}</li>
        ))}
      </ul>

      <h3>Even Players</h3>
      <ul>
        {evenTeam.map((player, index) => (
          <li key={index}>{player}</li>
        ))}
      </ul>

      <h3>List of Indian Players Merged:</h3>
      <ul>
        {mergedPlayers.map((player, index) => (
          <li key={index}>{player}</li>
        ))}
      </ul>
    </div>
  );
}

export default IndianPlayers;
