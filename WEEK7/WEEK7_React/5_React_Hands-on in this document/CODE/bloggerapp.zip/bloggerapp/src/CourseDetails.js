import React from "react";

function CourseDetails() {
  return (
    <div style={{ borderLeft: "4px solid green", paddingLeft: 20 }}>
      <h2>Course Details</h2>
      <p><b>Angular</b><br />4/5/2021</p>
      <p><b>React</b><br />6/1/2021</p>
    </div>
  );
}

export default CourseDetails;
