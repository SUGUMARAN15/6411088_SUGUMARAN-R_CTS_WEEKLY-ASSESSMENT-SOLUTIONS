import React from "react";

function BlogDetails() {
  return (
    <div style={{ borderLeft: "4px solid green", paddingLeft: 20 }}>
      <h2>Blog Details</h2>
      <p><b>React Learning</b><br />Stephen Biz<br />Welcome to learning React!</p>
      <p><b>Installation</b><br />Schwedenizer<br />You can install React from npm.</p>
    </div>
  );
}

export default BlogDetails;
