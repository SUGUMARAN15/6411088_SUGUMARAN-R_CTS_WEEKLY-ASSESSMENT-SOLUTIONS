import React from "react";
import BookDetails from "./BookDetails";
import BlogDetails from "./BlogDetails";
import CourseDetails from "./CourseDetails";

import { books } from "./data";

function App() {
  const showBooks = true;
  const showBlogs = true;
  const showCourses = true;

  return (
    <div style={{ display: "flex", justifyContent: "space-around", marginTop: 40 }}>
      {showCourses && <CourseDetails />}
      {showBooks ? <BookDetails books={books} /> : <p>No Book Data</p>}
      {showBlogs && <BlogDetails />}
    </div>
  );
}

export default App;
