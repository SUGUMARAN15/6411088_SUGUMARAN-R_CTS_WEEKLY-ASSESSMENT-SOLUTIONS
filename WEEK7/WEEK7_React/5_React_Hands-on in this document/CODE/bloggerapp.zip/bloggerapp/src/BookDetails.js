import React from "react";

function BookDetails(props) {
  return (
    <div style={{ borderLeft: "4px solid green", paddingLeft: 20 }}>
      <h2>Book Details</h2>
      <ul>
        {props.books.map((book) => (
          <div key={book.id}>
            <h3>{book.bname}</h3>
            <h4>{book.price}</h4>
          </div>
        ))}
      </ul>
    </div>
  );
}

export default BookDetails;
