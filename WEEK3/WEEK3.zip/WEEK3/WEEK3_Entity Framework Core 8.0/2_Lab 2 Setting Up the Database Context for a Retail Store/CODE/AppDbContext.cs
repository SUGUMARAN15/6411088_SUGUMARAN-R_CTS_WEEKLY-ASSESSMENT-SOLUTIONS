using Microsoft.EntityFrameworkCore;

public class AppDbContext : DbContext
{
    public DbSet<Product> Products { get; set; }  // Maps to Products table
    public DbSet<Category> Categories { get; set; }  // Maps to Categories table

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
       optionsBuilder.UseSqlServer("Server=localhost\\SQLEXPRESS;Database=RetailDb;Trusted_Connection=True;TrustServerCertificate=True;");


    }
}
